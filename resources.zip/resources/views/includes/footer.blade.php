<footer>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <p class="pt-4 pb-2">
                    2021 Copyright Store. All Rights Reserved. Mumtaz Sport by Muhammad Irham Syarif
                </p>
            </div>
        </div>
    </div>
</footer>
